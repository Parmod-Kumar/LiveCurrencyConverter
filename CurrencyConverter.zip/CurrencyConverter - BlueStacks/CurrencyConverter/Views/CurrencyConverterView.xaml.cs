﻿using System.Windows.Input;

namespace CurrencyConverter.Views
{
    /// <summary>
    /// Interaction logic for CurrencyConverterView.xaml
    /// </summary>
    public partial class CurrencyConverterView
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CurrencyConverterView"/> class.
        /// </summary>
        public CurrencyConverterView()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the OnPreviewTextInput event of the UIElement control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="TextCompositionEventArgs"/> instance containing the event data.</param>
        private void UIElement_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            //Regex regex = new Regex("^[0-9]([.,][0-9]{1,3})?$");
            //e.Handled = regex.IsMatch(e.Text);
        }
    }
}
