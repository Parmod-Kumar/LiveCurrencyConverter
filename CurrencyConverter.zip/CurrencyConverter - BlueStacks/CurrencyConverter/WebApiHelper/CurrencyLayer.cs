﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using CurrencyConverter.Models;
using Newtonsoft.Json;

namespace CurrencyConverter.WebApiHelper
{
    /// <summary>
    /// Currency Layer
    /// </summary>
    public class CurrencyLayer
    {
        #region Public Methods

        /// <summary>
        /// Gets the supported currencies.
        /// </summary>
        /// <returns>CurrencyDetails</returns>
        public CurrencyDetails GetSupportedCurrencies()
        {
            var config = ConfigurationManager.AppSettings.AllKeys.Contains(Constants.Constants.CurrencyFileKey)
                ? ConfigurationManager.AppSettings[Constants.Constants.CurrencyFileKey]
                : string.Empty;
            var currentDir = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            if (currentDir == null) return null;
            var currentDirFile = Path.Combine(currentDir, config);
            var currencyData = File.ReadAllText(currentDirFile);
            return JsonConvert.DeserializeObject<CurrencyDetails>(currencyData);
        }

        /// <summary>
        /// Gets the currency rates.
        /// </summary>
        /// <param name="fromCurrency">From currency.</param>
        /// <returns></returns>
        public Dictionary<string, double> GetCurrencyRates(Currency fromCurrency)
        {
            Dictionary<string, double> returnValue = new Dictionary<string, double>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://api.exchangeratesapi.io");

                //HTTP GET
                var responseTask = client.GetAsync("/latest?base=" + fromCurrency.Code);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<RootObject>();
                    readTask.Wait();
                    returnValue = FillCurrencyRate(readTask.Result.rates);
                }
            }
            return returnValue;
        }

        private Dictionary<string, double> FillCurrencyRate(Rates resultRates)
        {
            var dictionary = new Dictionary<string, double>();
            dictionary["BGN"] = resultRates.BGN;
            dictionary["CAD"] = resultRates.CAD;
            dictionary["BRL"] = resultRates.BRL;
            dictionary["HUF"] = resultRates.HUF;
            dictionary["DKK"] = resultRates.DKK;
            dictionary["JPY"] = resultRates.JPY;
            dictionary["ILS"] = resultRates.ILS;
            dictionary["TRY"] = resultRates.TRY;
            dictionary["RON"] = resultRates.RON;
            dictionary["GBP"] = resultRates.GBP;
            dictionary["PHP"] = resultRates.PHP;
            dictionary["HRK"] = resultRates.HRK;
            dictionary["NOK"] = resultRates.NOK;
            dictionary["ZAR"] = resultRates.ZAR;
            dictionary["MXN"] = resultRates.MXN;
            dictionary["AUD"] = resultRates.AUD;
            dictionary["USD"] = resultRates.USD;
            dictionary["KRW"] = resultRates.KRW;
            dictionary["HKD"] = resultRates.HKD;
            dictionary["EUR"] = resultRates.EUR;
            dictionary["ISK"] = resultRates.ISK;
            dictionary["CZK"] = resultRates.CZK;
            dictionary["THB"] = resultRates.THB;
            dictionary["MYR"] = resultRates.MYR;
            dictionary["NZD"] = resultRates.NZD;
            dictionary["PLN"] = resultRates.PLN;
            dictionary["CHF"] = resultRates.CHF;
            dictionary["SEK"] = resultRates.SEK;
            dictionary["CNY"] = resultRates.CNY;
            dictionary["SGD"] = resultRates.SGD;
            dictionary["INR"] = resultRates.INR;
            dictionary["IDR"] = resultRates.IDR;
            dictionary["RUB"] = resultRates.RUB;
            return dictionary;
        }

        #endregion
    }
}
